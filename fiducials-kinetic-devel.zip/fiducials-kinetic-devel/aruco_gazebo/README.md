# aruco_gazebo
An emulator for aruco_detect that uses gazebo pose data instead of image processing to reduce cpu load and work around aliasing problems.

In an effort to provide as much of a drop in replacement as possible most of the launch file include params remain the same.

